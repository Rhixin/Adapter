package roundHolePeg;

public class RoundPeg {
    private int radius;

    public RoundPeg(int radius){
        this.radius = radius;
    }

    public RoundPeg(){
        this.radius = 0;
    }

    public int getRadius() {
        return radius;
    }
}
