package ClassvsObjectAdapter;

public class Main {
    public static void main(String[] args) {
        RoundMouseHole hole = new RoundMouseHole(5);
        CircleCheese rpeg = new CircleCheese(5);
        System.out.println(hole.fits(rpeg));

        SquareCheese small_speg = new SquareCheese(5);
        SquareCheese large_speg = new SquareCheese(10);

        //ERROR ni (can't fit a square sa circle)
        //System.out.println(hole.fits(small_speg));

        // object adapter
        RoundThings small_sqpeg_adapter = new SquareCheeseObjectAdapter(small_speg);
        RoundThings large_sqpeg_adapter = new SquareCheeseObjectAdapter(large_speg);

        System.out.println("Object Adapter (small): " + hole.fits(small_sqpeg_adapter));
        System.out.println("Object Adapter (large): " + hole.fits(large_sqpeg_adapter));

        // class adapter
        small_sqpeg_adapter = new SquareCheeseClassAdapter(small_speg.getWidth());
        large_sqpeg_adapter = new SquareCheeseClassAdapter(large_speg.getWidth());

        System.out.println("Class Adapter (small): " + hole.fits(small_sqpeg_adapter));
        System.out.println("Class Adapter (large): " + hole.fits(large_sqpeg_adapter));
    }
}

