package ClassvsObjectAdapter;

public class SquareCheese {
    private int width;

    public SquareCheese(int width){
        this.width = width;
    }

    public int getWidth(){
        return this.width;
    }
}
