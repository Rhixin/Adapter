package ClassvsObjectAdapter;

public class RoundMouseHole implements RoundThings {
    private int radius;

    public RoundMouseHole(int radius){
        this.radius = radius;
    }

    public boolean fits(RoundThings peg){
        return (radius >= peg.getRadius());
    }

    @Override
    public int getRadius() {
        return radius;
    }
}
