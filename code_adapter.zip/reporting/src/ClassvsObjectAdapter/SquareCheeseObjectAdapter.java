package ClassvsObjectAdapter;


public class SquareCheeseObjectAdapter implements RoundThings{
    private SquareCheese peg;

    public SquareCheeseObjectAdapter(SquareCheese peg){
        this.peg = peg;
    }

    @Override
    public int getRadius() {
        return (int) (peg.getWidth() *  Math.sqrt(2) / 2);
    }
}
