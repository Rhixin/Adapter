package ClassvsObjectAdapter;

public interface RoundThings {
    int getRadius();
}