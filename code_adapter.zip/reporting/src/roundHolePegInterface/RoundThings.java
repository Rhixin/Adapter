package roundHolePegInterface;

public interface RoundThings {
    int getRadius();
}
